// Firebase Infrastructure Keys extracted from base template
const FIREBASE_API_KEY = "AIzaSyBdwsshU3MErA5Cgxf7ChmW4g2NGVvCMnk"; 
const AUTH_BASE = "https://identitytoolkit.googleapis.com/v1"; 
const REFRESH_URL = "https://securetoken.googleapis.com/v1/token?key=" + FIREBASE_API_KEY; 
const DB_URL = "https://lectura-campus-workspace-default-rtdb.firebaseio.com"; 
const STORAGE_KEY = "antbyte_platform_data"; 

const state = {   
    authToken: "", refreshToken: "", uid: "", email: "", name: "",   
    loggedIn: false, online: navigator.onLine, page: "EXPLORE",
    items: []
}; 

const $ = id => document.getElementById(id);
const page = $("page");
const title = $("pageTitle");
const toast = $("toast"); 

function esc(v) {
    return String(v ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"}[c]));
} 

function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
        name: state.name, email: state.email, refreshToken: state.refreshToken, uid: state.uid
    }));
} 

function load() {
    try {
        const d = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
        if (!d) return;
        Object.assign(state, d);
        state.loggedIn = !!(state.uid && state.name);
    } catch (e) {}
} 

function notify(msg) {
    toast.textContent = msg;
    toast.style.display = "block";
    clearTimeout(notify.t);
    notify.t = setTimeout(() => toast.style.display = "none", 3200);
} 

function updateStatus() {
    if ($("loginStatus")) $("loginStatus").innerHTML = state.loggedIn ? `Logged into AntByte<br><b>${esc(state.name)}</b>` : "Not signed in";
    if ($('connection')) $('connection').textContent = state.online ? "Online" : "Offline mode";
    if ($("btnExplore")) $("btnExplore").classList.toggle("active", state.page === "EXPLORE");
    if ($("btnShare")) $("btnShare").classList.toggle("active", state.page === "SHARE");
    if ($("btnAuth")) $("btnAuth").classList.toggle("active", state.page === "AUTH");
} 

function showView(p) {
    state.page = p;
    if (p === "EXPLORE") { title.textContent = "Explore Platform"; renderExplore(); }
    if (p === "SHARE") { title.textContent = "Share App & Story"; renderShare(); }
    if (p === "AUTH") { title.textContent = "My Account"; renderAuth(); }
    updateStatus();
} 

// --- VIEWS GENERATORS ---

async function renderExplore() {
    page.innerHTML = `<p class="info">Discover apps built on the AntByte base framework and read their origin stories.</p><div id="itemsContainer"><p class="info">Loading feeds...</p></div>`;
    try {
        const res = await fetch(`${DB_URL}/antbyte_items.json`);
        const data = await res.json();
        const container = $("itemsContainer");
        if(!data) {
            container.innerHTML = `<div class="empty">No apps or stories shared yet. Be the first!</div>`;
            return;
        }
        
        const html = Object.values(data).reverse().map(item => `
            <div class="card">
                <h3>${esc(item.title)}</h3>
                <p class="muted-small">Shared by ${esc(item.author)}</p>
                <p style="margin: 10px 0;">${esc(item.story)}</p>
                ${item.link ? `<a href="${esc(item.link)}" target="_blank" class="app-link-btn">Launch App External Link ↗</a>` : ''}
            </div>
        `).join("");
        container.innerHTML = html;
    } catch(e) {
        $("itemsContainer").innerHTML = `<div class="empty">Error updating timeline. Ensure you are connected.</div>`;
    }
}

function renderShare() {
    if (!state.loggedIn) {
        page.innerHTML = `<div class="empty">You must be logged in to post stories or link your apps.<br><br><button class="primary" onclick="showView('AUTH')">Go to Sign In</button></div>`;
        return;
    }
    page.innerHTML = `
        <div class="form">
            <p class="info">Publish details about your applications hosted here or elsewhere.</p>
            <input id="itemTitle" placeholder="Application / Story Title">
            <input id="itemLink" type="url" placeholder="App Link URL (Optional)">
            <textarea id="itemStory" placeholder="Share your development story, architecture features or usage documentation..." rows="6"></textarea>
            <button class="primary" id="btnSubmitPost">Publish to AntByte Feed</button>
        </div>
    `;
    $("btnSubmitPost").onclick = submitPost;
}

function renderAuth() {
    if (state.loggedIn) {
        page.innerHTML = `
            <div class="card">
                <h3>Profile Session</h3>
                <p><strong>Name:</strong> ${esc(state.name)}</p>
                <p><strong>Email:</strong> ${esc(state.email)}</p>
                <p><strong>AntByte ID:</strong> ${esc(state.uid)}</p>
            </div>
            <button class="danger" id="btnSignOut">Sign Out</button>
        `;
        $("btnSignOut").onclick = signOut;
        return;
    }
    page.innerHTML = `
        <div class="form">
            <p class="info">Access your unified base configuration setup dashboard.</p>
            <input id="nameInput" placeholder="Display Name (For registration profiles)">
            <input id="emailInput" type="email" placeholder="Developer Email">
            <input id="passwordInput" type="password" placeholder="Password Access Pin">
            <div class="row">
                <button class="primary" id="btnLogin">Sign In</button>
                <button class="plain" id="btnSignup">Create Base Profile</button>
            </div>
        </div>
    `;
    $("btnLogin").onclick = signIn;
    $("btnSignup").onclick = signUp;
}

// --- DATABASE INTERACTIONS ---

async function submitPost() {
    const title = $("itemTitle").value.trim();
    const link = $("itemLink").value.trim();
    const story = $("itemStory").value.trim();

    if (!title || !story) return notify("Please fill out the Title and Story fields.");
    
    const payload = {
        title, link, story, author: state.name, uid: state.uid, timestamp: Date.now()
    };

    try {
        const url = `${DB_URL}/antbyte_items.json?auth=${encodeURIComponent(state.authToken)}`;
        const r = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        if (!r.ok) throw new Error("Could not authenticate database storage operation.");
        notify("App payload broadcasted successfully!");
        showView("EXPLORE");
    } catch(e) {
        notify(e.message);
    }
}

// --- CORE AUTHENTICATION APIS PIPELINES ---

async function firebaseAuthRequest(path, body) {
    const r = await fetch(AUTH_BASE + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });
    let d = {};
    try { d = await r.json(); } catch(e) {}
    if (!r.ok || d.error) {
        const msg = d?.error?.message || "Auth error occurred.";
        const errMap = {
            EMAIL_EXISTS: "That email is already registered on AntByte.",
            EMAIL_NOT_FOUND: "Authentication failed. Incorrect email or password.",
            INVALID_PASSWORD: "Authentication failed. Incorrect email or password.",
            INVALID_LOGIN_CREDENTIALS: "No platform profiles matched these credentials."
        };
        throw new Error(errMap[msg] || msg);
    }
    return d;
} 

async function signIn() {
    const email = $("emailInput")?.value.trim();
    const password = $("passwordInput")?.value;
    if (!email || !password) return notify("Enter credentials.");
    try {
        const d = await firebaseAuthRequest("/accounts:signInWithPassword?key=" + FIREBASE_API_KEY, {
            email, password, returnSecureToken: true
        });
        applyAuth(d);
        notify("Authenticated successfully.");
        showView("EXPLORE");
    } catch (e) { notify(e.message); }
} 

async function signUp() {
    const name = $("nameInput")?.value.trim();
    const email = $("emailInput")?.value.trim();
    const password = $("passwordInput")?.value;
    if (!email || !password) return notify("Email and password parameters missing.");
    if (password.length < 6) return notify("Security baseline requires 6 characters minimum.");
    try {
        const d = await firebaseAuthRequest("/accounts:signUp?key=" + FIREBASE_API_KEY, {
            email, password, returnSecureToken: true
        });
        state.name = name || email.split("@")[0];
        applyAuth(d);
        notify("AntByte node allocated successfully.");
        showView("EXPLORE");
    } catch (e) { notify(e.message); }
} 

function applyAuth(d) {
    state.authToken = d.idToken || "";
    state.refreshToken = d.refreshToken || "";
    state.uid = d.localId || "";
    state.email = d.email || state.email;
    state.loggedIn = !!(state.authToken && state.uid);
    if (!state.name) state.name = state.email.split("@")[0];
    save();
} 

async function refreshSession() {
    if (!state.refreshToken) return;
    try {
        const r = await fetch(REFRESH_URL, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "grant_type=refresh_token&refresh_token=" + encodeURIComponent(state.refreshToken)
        });
        const d = await r.json();
        if (!r.ok || d.error) throw new Error();
        state.authToken = d.id_token || "";
        state.refreshToken = d.refresh_token || state.refreshToken;
        state.uid = d.user_id || state.uid;
        state.loggedIn = true;
        save();
        updateStatus();
    } catch (e) {
        state.authToken = "";
        state.loggedIn = false;
        showView("AUTH");
    }
} 

function signOut() {
    state.loggedIn = false; state.authToken = ""; state.refreshToken = ""; state.uid = ""; state.email = ""; state.name = "";
    save();
    notify("Logged out from ecosystem framework.");
    showView("EXPLORE");
} 

// --- EVENT HANDLERS ---
if ($("btnExplore")) $("btnExplore").onclick = () => showView("EXPLORE");
if ($("btnShare")) $("btnShare").onclick = () => showView("SHARE");
if ($("btnAuth")) $("btnAuth").onclick = () => showView("AUTH");

window.addEventListener("online", () => { state.online = true; updateStatus(); });
window.addEventListener("offline", () => { state.online = false; updateStatus(); });

// Init Boot Process
load();
showView("EXPLORE");
if (state.refreshToken) refreshSession();